const models = require("../models");
const { Servico, Cliente, Usuario, Ativo, TipoServico } = models;
const { logTriggerEvent } = require("../utils/auditLogger");
const { validateServicoPayload, ServicoValidationError } = require("../services/servicoValidator");

const servicoController = {
  // Listar todos os serviços com seus relacionamentos
  async listar(req, res) {
    try {
      const servicos = await Servico.findAll({
        include: [
          { model: Cliente, as: "cliente" },
          { model: Usuario, as: "responsavel" },
          { model: Ativo, as: "ativo" },
          { model: TipoServico, as: "tipoServico" }
        ]
      });
      return res.status(200).json(servicos);
    } catch (error) {
      return res.status(500).json({ message: "Erro ao listar serviços", detalhes: error.message });
    }
  },

  // Buscar serviço por ID
  async buscarPorId(req, res) {
    try {
      const { id } = req.params;
      const servico = await Servico.findByPk(id, {
        include: [
          { model: Cliente, as: "cliente" },
          { model: Usuario, as: "responsavel" },
          { model: Ativo, as: "ativo" },
          { model: TipoServico, as: "tipoServico" }
        ]
      });
      if (!servico) return res.status(404).json({ message: "Serviço não encontrado" });
      return res.status(200).json(servico);
    } catch (error) {
      return res.status(500).json({ message: "Erro ao buscar serviço", detalhes: error.message });
    }
  },

  // Criar novo serviço
  async criar(req, res) {
    try {
      const {
        descricao,
        status,
        dataAgendada,
        dataConclusao,
        detalhes,
        clienteId,
        usuarioId,
        ativoId,
        tipoServicoId
      } = req.body;

      if (!descricao) {
        return res.status(400).json({ message: "Campo descricao é obrigatório" });
      }

      const validation = await validateServicoPayload(models, req.body, { requireAtivo: true });

      const novoServico = await Servico.create({
        descricao,
        status,
        dataAgendada,
        dataConclusao,
        detalhes,
        clienteId: validation.resolvedClienteId,
        usuarioId,
        ativoId: validation.resolvedAtivoId,
        tipoServicoId
      });

      return res.status(201).json(novoServico);
    } catch (error) {
      if (error instanceof ServicoValidationError) {
        return res.status(error.statusCode).json({ message: error.message, detalhes: error.details });
      }
      return res.status(400).json({ message: "Erro ao criar serviço", detalhes: error.message });
    }
  },

  // Atualizar serviço existente
  async atualizar(req, res) {
    try {
      const { id } = req.params;
      const {
        descricao,
        status,
        dataAgendada,
        dataConclusao,
        detalhes,
        clienteId,
        usuarioId,
        ativoId,
        tipoServicoId
      } = req.body;

      const servico = await Servico.findByPk(id);
      if (!servico) return res.status(404).json({ message: "Serviço não encontrado" });

      const validation = await validateServicoPayload(models, req.body, { existingServico: servico });

      await servico.update({
        descricao,
        status,
        dataAgendada,
        dataConclusao,
        detalhes,
        clienteId: validation.resolvedClienteId,
        usuarioId,
        ativoId: validation.resolvedAtivoId,
        tipoServicoId
      });

      return res.status(200).json(servico);
    } catch (error) {
      if (error instanceof ServicoValidationError) {
        return res.status(error.statusCode).json({ message: error.message, detalhes: error.details });
      }
      return res.status(400).json({ message: "Erro ao atualizar serviço", detalhes: error.message });
    }
  },

  // Desativar serviço (soft delete)
  async desativar(req, res) {
    try {
      const { id } = req.params;
      const servico = await Servico.findByPk(id);
      if (!servico) return res.status(404).json({ message: "Serviço não encontrado" });

      await servico.destroy(); // com paranoid: true, isso faz soft delete
      return res.status(200).json({ message: "Serviço desativado com sucesso" });
    } catch (error) {
      return res.status(500).json({ message: "Erro ao desativar serviço", detalhes: error.message });
    }
  },

  // Criar novo serviço usando função do banco (create_servico)
  async criarDb(req, res) {
    try {
      const {
        descricao,
        status,
        dataAgendada,
        detalhes,
        clienteId,
        usuarioId,
        ativoId,
        tipoServicoId
      } = req.body;

      if (!descricao || !ativoId) {
        return res.status(400).json({ message: 'Campos obrigatórios: descricao, ativoId' });
      }

      const validation = await validateServicoPayload(models, req.body, { requireAtivo: true });

      logTriggerEvent('create_servico:request', {
        ativoId: validation.resolvedAtivoId,
        descricao,
        status: status || 'pendente',
        clienteId: validation.resolvedClienteId,
        usuarioId,
        tipoServicoId,
        dataAgendada
      });

      let detalhesValue = detalhes;
      if (detalhes && typeof detalhes === 'object') {
        try { detalhesValue = JSON.stringify(detalhes); } catch (_) { detalhesValue = '{}'; }
      }

      const { sequelize } = require('../models');
      const rows = await sequelize.query(
        `SELECT create_servico(:descricao, :ativoId, :status, :clienteId, :usuarioId, :tipoServicoId, :dataAgendada, :detalhes) AS id`,
        {
          replacements: {
            descricao,
            ativoId: validation.resolvedAtivoId,
            status: status || 'pendente',
            clienteId: validation.resolvedClienteId,
            usuarioId: Number.isInteger(usuarioId) ? usuarioId : null,
            tipoServicoId: Number.isInteger(tipoServicoId) ? tipoServicoId : null,
            dataAgendada: dataAgendada || null,
            detalhes: detalhesValue || '{}'
          },
          type: sequelize.QueryTypes.SELECT
        }
      );

      const servicoId = rows[0]?.id ?? rows.id;
      logTriggerEvent('create_servico:response', { servicoId, rowsReturned: Array.isArray(rows) ? rows.length : 1 });
      const criado = await Servico.findByPk(servicoId, {
        include: [
          { model: Cliente, as: 'cliente' },
          { model: Usuario, as: 'responsavel' },
          { model: Ativo, as: 'ativo' },
          { model: TipoServico, as: 'tipoServico' }
        ]
      });
      return res.status(201).json(criado);
    } catch (error) {
      if (error instanceof ServicoValidationError) {
        return res.status(error.statusCode).json({ message: error.message, detalhes: error.details });
      }
      logTriggerEvent('create_servico:error', { message: error.message });
      return res.status(400).json({ message: 'Erro ao criar serviço (DB)', detalhes: error.message });
    }
  }
};

module.exports = servicoController;


